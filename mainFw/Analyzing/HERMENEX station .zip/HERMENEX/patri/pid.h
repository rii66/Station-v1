#ifndef PATRI_PID_H
#define PATRI_PID_H

#include <Arduino.h>
#include "config.h"
#include "boost.h"

// PID internal
extern float pidError;
extern float pidIntegral;
extern float pidDerivative;
extern float lastError;

// Target
extern int targetTemp;

// API
int readTemp();
void detectTip();
void updatePID();
void handleSafety();

#endif