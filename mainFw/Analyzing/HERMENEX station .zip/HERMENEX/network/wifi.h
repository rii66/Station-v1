#ifndef WIFI_H
#define WIFI_H

#include <WiFi.h>
#include <ESPmDNS.h>
#include "config.h"

inline void setupWiFi() {
  WiFi.mode(WIFI_AP_STA);

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  WiFi.softAP(AP_SSID, AP_PASS);

  Serial.println("Connecting WiFi...");

  unsigned long start = millis();

  while (WiFi.status() != WL_CONNECTED &&
         millis() - start < 10000) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("STA IP: ");
    Serial.println(WiFi.localIP());

    // Mulai mDNS
    if (MDNS.begin("solder")) {
      Serial.println("mDNS started");
      Serial.println("http://solder.local");
    } else {
      Serial.println("mDNS failed!");
    }
  }

  Serial.print("AP IP: ");
  Serial.println(WiFi.softAPIP());
}

#endif