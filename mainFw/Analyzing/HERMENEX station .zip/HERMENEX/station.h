#ifndef STATION_H
#define STATION_H

#include <Arduino.h>

void initStations();
void updateStations();

// belum ada rencana pake tombol ganti station 
// void handleStationEncoder(int delta);
// void handleStationButton();

#endif