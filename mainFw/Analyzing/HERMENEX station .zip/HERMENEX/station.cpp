#include "station.h"

#include "GlobalState.h"

#include "patri/pid.h"
#include "patri/pwm.h"
#include "patri/ptc.h"

#include "siroccro/handler.h"

void initStations() {
    // Solder
    initPWM();
    initPTC();

    // Hot Air
    initAirHandler();
}

void updateStations() {
    // Kedua station boleh berjalan bersamaan
    updatePID();
    updateAirHandler();
}

/*       aktifkan lagi jika diperlukan.  
void handleStationEncoder(int delta) {
    if (delta == 0) return;

    switch (activeStation) {

        case STATION_SOLDER:
            // Kontrol Solder akan kita sambungkan
            // setelah jalur menu/dashboard lama diaudit
            break;

        case STATION_HOTAIR:
            handleAirEncoder(delta);
            break;
    }
}

void handleStationButton() {
    switch (activeStation) {

        case STATION_SOLDER:
            // Belum mengambil alih tombol Solder
            break;

        case STATION_HOTAIR:
            handleAirButton();
            break;
    }
}
                */
