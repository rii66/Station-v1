#include <Arduino.h>

#include <Wire.h>
#include <U8g2lib.h>
#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>
#include <ArduinoOTA.h>
#include <Preferences.h>


// ================= CONFIG & GLOBAL STATE =================

#include "config.h"
#include "GlobalState.h"


// ================= STORAGE =================

#include "storage/storage.h"


// ================= UI & DISPLAY =================

#include "display.h"
#include "ui.h"
#include "icons.h"
#include "pages.h"
#include "menuHandlr.h"
#include "bootanim.h"


// ================= HARDWARE =================

#include "encoder.h"
#include "buzzer.h"
#include "motion.h"
// #include "rgb.h"        // gpio habis ;(


// ================= PATRI / SOLDER =================

#include "patri/boost.h"
#include "patri/tip.h"
#include "patri/pid.h"
#include "patri/pwm.h"
#include "patri/ptc.h"


// ================= SIROCCRO / HOT AIR =================

#include "siroccro/AirCal.h"
#include "siroccro/AirPid.h"
#include "siroccro/AirTemp.h"
#include "siroccro/ZeroCross.h"
#include "siroccro/fan.h"
#include "siroccro/hotgun.h"
#include "siroccro/handler.h"


// ================= NETWORK =================

#include "network/wifi_manager.h"
#include "network/webserver.h"
#include "network/websocket_handler.h"
#include "network/web.h"
#include "network/ota.h"


// ================= MONITORING =================

#include "monitoring.h"