#ifndef RGB_H
#define RGB_H

#include <Arduino.h>
#include "state.h"

/* ===== FUNCTION ===== */
void initRGB();
void updateRGB();
void setRGB(uint8_t r, uint8_t b);

#endif