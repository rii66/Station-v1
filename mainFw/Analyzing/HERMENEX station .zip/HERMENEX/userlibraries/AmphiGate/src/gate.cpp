#include "gate.h"

// ==========================================
// EXTERNAL CPP SOURCE
// ========================================
#include "/storage/emulated/0/HERMENEX/bootanim.cpp"
#include "/storage/emulated/0/HERMENEX/encoder.cpp"
#include "/storage/emulated/0/HERMENEX/buzzer.cpp"
#include "/storage/emulated/0/HERMENEX/GlobalState.cpp"
#include "/storage/emulated/0/HERMENEX/menuHandlr.cpp"
#include "/storage/emulated/0/HERMENEX/station.cpp"

// Network
#include "/storage/emulated/0/HERMENEX/network/websocket_handler.cpp"

// Ui
#include "/storage/emulated/0/HERMENEX/ui/display.cpp"
#include "/storage/emulated/0/HERMENEX/ui/icons.cpp"
#include "/storage/emulated/0/HERMENEX/ui/display.cpp"
#include "/storage/emulated/0/HERMENEX/ui/uiDashboard.cpp"

// Storage 
#include "/storage/emulated/0/HERMENEX/storage/storage.cpp"

// Siroccro 
#include "/storage/emulated/0/HERMENEX/siroccro/handler.cpp"

// Patri 
#include "/storage/emulated/0/HERMENEX/patri/boost.cpp"
#include "/storage/emulated/0/HERMENEX/patri/pidcpp"
#include "/storage/emulated/0/HERMENEX/patri/ptc.cpp"
#include "/storage/emulated/0/HERMENEX/patri/pwm.cpp"
#include "/storage/emulated/0/HERMENEX/patri/pid.cpp"
