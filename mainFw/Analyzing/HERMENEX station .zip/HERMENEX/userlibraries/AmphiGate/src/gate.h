#pragma once

#include <Arduino.h>

// =========================================
// GLOBAL HEADER DARI FOLDER EKSTERNAL
// =========================================

#include "/storage/emulated/0/HERMENEX/.."
#include ..
#include ..
// =========================================
// Station Gate
// =========================================

//sirocco 
#include "/storage/emulated/0/HERMENEX/siroccro/files.h"

// patri
#include "/storage/emulated/0/HERMENEX/patri/files.h"