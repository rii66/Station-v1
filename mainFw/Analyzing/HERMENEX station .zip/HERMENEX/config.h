#ifndef CONFIG_H
#define CONFIG_H

// ================= WIFI & OTA =================
#define WIFI_SSID           "ICA ELEK"
#define WIFI_PASS           "koyok tekek"

#define AP_SSID             "SolderStation"
#define AP_PASS             "88889999"

#define OTA_HOSTNAME        "SolderStation"


// ================= PIN CONFIG (ESP32-C3 Super Mini) =================

// ----- Solder (nama lama dipertahankan) -----
#define TEMP_PIN            0       // Solder ADC
#define PWM_PIN             2       // Solder PWM

// ----- Hot Air (baru) -----
#define PIN_HOTAIR_ADC      1
#define PIN_FAN_PWM         3
#define PIN_ZERO_CROSS      4
#define PIN_HEATER_AC       10

// ----- OLED -----
#define OLED_SDA            6
#define OLED_SCL            7

// ----- Encoder -----
#define ENC_A               20
#define ENC_B               21
#define ENC_SW              5

// ----- Other -----
#define BUZZER_PIN          8
#define PIN_RED_SW_HOTGUN   9
// #define PIN_RED_SW_SOLDER

// Pin yang sudah tidak dipakai (di-comment biar jelas)
// #define RGB_RED          9
// #define RGB_BLUE         10
// #define MOTION_PIN       1


// ================= PID SOLDER =================
#define PID_KP_T12          3.2f
#define PID_KI_T12          0.12f
#define PID_KD_T12          1.8f

#define PID_KP_C210         2.8f
#define PID_KI_C210         0.10f
#define PID_KD_C210         1.4f

#define PID_KP_CUSTOM       3.0f
#define PID_KI_CUSTOM       0.11f
#define PID_KD_CUSTOM       1.6f


// ================= TEMP LIMIT =================
#define TEMP_MIN            100
#define TEMP_MAX_T12        450
#define TEMP_MAX_C210       380
#define TEMP_MAX_CUSTOM     600

// Hot Air (bisa disesuaikan nanti)
#define TEMP_MAX_HOTAIR     550


// ================= DEFAULT TEMP =================
#define DEFAULT_TEMP            320
#define DEFAULT_BOOST_TEMP      470
#define DEFAULT_SLEEP_TEMP      195
#define DEFAULT_BOOST_TIME      12

#define DEFAULT_HOTAIR_TEMP     300     // default hot air


// ================= OFFSET =================
#define OFFSET_TEMP_T12         0
#define OFFSET_TEMP_C210        0
#define OFFSET_TEMP_CUSTOM      0

#define OFFSET_ADC_T12          0
#define OFFSET_ADC_C210         0
#define OFFSET_ADC_CUSTOM       0


// ================= ADC DETECT =================
#define ADC_NO_TIP              150
#define ADC_NO_TIP_PTC          4000
#define ADC_CUSTOM_MIN          501
#define ADC_CUSTOM_MAX          599


// ================= PWM CONFIG =================
#define PWM_FREQ                20000   // 20kHz
#define PWM_RES                 8       // 8-bit
#define PWM_MAX_VAL             255

#define MAX_PWM_T12             255
#define MAX_PWM_C210            71
#define MAX_PWM_CUSTOM          255

// Hot Air PWM limit (bisa disesuaikan)
#define MAX_PWM_HOTAIR          255
#define MAX_FAN_PWM             255


#endif