#include "../storage/storage.h"
#include <Preferences.h>

#include "config.h"
#include "GlobalState.h"
#include "Patri/tip.h"

Preferences prefs;

Storage storage;


// =============================================================
// BEGIN
// =============================================================

void Storage::begin()
{
    prefs.begin("iron", false);
}


// =============================================================
// SIROCCRO
// =============================================================

void Storage::loadSiroccroCalibration(int &c0, int &c1, int &c2)
{
    c0 = prefs.getInt("sc_c0", 2348);
    c1 = prefs.getInt("sc_c1", 3004);
    c2 = prefs.getInt("sc_c2", 3400);
}


void Storage::saveSiroccroCalibration(int c0, int c1, int c2)
{
    prefs.putInt("sc_c0", c0);
    prefs.putInt("sc_c1", c1);
    prefs.putInt("sc_c2", c2);
}


void Storage::loadSiroccroSettings(int &temp, int &fan)
{
    temp = prefs.getInt("sc_temp", DEFAULT_TEMP);
    fan  = prefs.getInt("sc_fan", 0);
}


void Storage::saveSiroccroSettings(int temp, int fan)
{
    prefs.putInt("sc_temp", temp);
    prefs.putInt("sc_fan", fan);
}


void Storage::loadSiroccroPID(float &kp, float &ki, float &kd)
{
    kp = prefs.getFloat("sc_kp", 12.0f);
    ki = prefs.getFloat("sc_ki", 0.6f);
    kd = prefs.getFloat("sc_kd", 25.0f);
}


void Storage::saveSiroccroPID(float kp, float ki, float kd)
{
    prefs.putFloat("sc_kp", kp);
    prefs.putFloat("sc_ki", ki);
    prefs.putFloat("sc_kd", kd);
}


// =============================================================
// PATRI - LOAD SETTINGS
// =============================================================

void Storage::loadSettings()
{
    targetTemp = prefs.getInt(
        "pt_temp",
        DEFAULT_TEMP
    );

    boostTemp = prefs.getInt(
        "pt_boostT",
        DEFAULT_BOOST_TEMP
    );

    boostTimeSec = prefs.getInt(
        "pt_boostS",
        DEFAULT_BOOST_TIME
    );

    sleepTemp = prefs.getInt(
        "pt_sleepT",
        DEFAULT_SLEEP_TEMP
    );

    sleepTimeSec = prefs.getInt(
        "pt_sleepS",
        240
    );

    buzzerEnabled = prefs.getBool(
        "pt_buzzer",
        true
    );

    currentTipMode = prefs.getInt(
        "pt_tipMode",
        TIP_ITEM_AUTO
    );

    // Validasi mode tip
    if (currentTipMode < TIP_ITEM_T12 ||
        currentTipMode > TIP_ITEM_CUSTOM)
    {
        currentTipMode = TIP_ITEM_AUTO;
    }


    // ---------------------------------------------------------
    // Load parameter masing-masing profile
    // ---------------------------------------------------------

    for (int i = 0; i < TOTAL_SUPPORTED_TIPS; i++)
    {
        TipConfig &tip = tipDatabase[i];

        String base = String("pt_") + tip.name;

        tip.kp = prefs.getFloat(
            (base + "_kp").c_str(),
            tip.kp
        );

        tip.ki = prefs.getFloat(
            (base + "_ki").c_str(),
            tip.ki
        );

        tip.kd = prefs.getFloat(
            (base + "_kd").c_str(),
            tip.kd
        );

        tip.tempOffset = prefs.getInt(
            (base + "_tOff").c_str(),
            tip.tempOffset
        );

        tip.adcOffset = prefs.getInt(
            (base + "_aOff").c_str(),
            tip.adcOffset
        );
    }


    // ---------------------------------------------------------
    // Custom profile
    // ---------------------------------------------------------

    {
        String base = String("pt_") + customTipProfile.name;

        customTipProfile.kp = prefs.getFloat(
            (base + "_kp").c_str(),
            customTipProfile.kp
        );

        customTipProfile.ki = prefs.getFloat(
            (base + "_ki").c_str(),
            customTipProfile.ki
        );

        customTipProfile.kd = prefs.getFloat(
            (base + "_kd").c_str(),
            customTipProfile.kd
        );

        customTipProfile.tempOffset = prefs.getInt(
            (base + "_tOff").c_str(),
            customTipProfile.tempOffset
        );

        customTipProfile.adcOffset = prefs.getInt(
            (base + "_aOff").c_str(),
            customTipProfile.adcOffset
    );
    }


    // ---------------------------------------------------------
    // Restore active profile
    // ---------------------------------------------------------

    switch (currentTipMode)
    {
        case TIP_ITEM_T12:
            applyTipProfile(&tipDatabase[0]);
            break;

        case TIP_ITEM_C210:
            applyTipProfile(&tipDatabase[1]);
            break;

        case TIP_ITEM_CUSTOM:
            applyTipProfile(&customTipProfile);
            break;

        case TIP_ITEM_AUTO:
        default:
            activeTip = nullptr;
            break;
    }
}


// =============================================================
// PATRI - SAVE SETTINGS
// =============================================================

void Storage::saveSettings()
{
    prefs.putInt(
        "pt_temp",
        targetTemp
    );
}


// =============================================================
// PATRI - LOAD PID
// =============================================================

void Storage::loadPID()
{
    if (!activeTip)
        return;

    String base = String("pt_") + activeTip->name;

    kp = prefs.getFloat(
        (base + "_kp").c_str(),
        activeTip->kp
    );

    ki = prefs.getFloat(
        (base + "_ki").c_str(),
        activeTip->ki
    );

    kd = prefs.getFloat(
        (base + "_kd").c_str(),
        activeTip->kd
    );
}


// =============================================================
// PATRI - SAVE PID
// =============================================================

void Storage::savePID()
{
    if (!activeTip)
        return;

    String base = String("pt_") + activeTip->name;

    prefs.putFloat(
        (base + "_kp").c_str(),
        kp
    );

    prefs.putFloat(
        (base + "_ki").c_str(),
        ki
    );

    prefs.putFloat(
        (base + "_kd").c_str(),
        kd
    );
}


// =============================================================
// PATRI - SAVE ACTIVE PID
// =============================================================

void Storage::saveActivePID()
{
    if (!activeTip)
        return;

    String base = String("pt_") + activeTip->name;

    prefs.putFloat(
        (base + "_kp").c_str(),
        activeTip->kp
    );

    prefs.putFloat(
        (base + "_ki").c_str(),
        activeTip->ki
    );

    prefs.putFloat(
        (base + "_kd").c_str(),
        activeTip->kd
    );
}


// =============================================================
// PATRI - BOOST
// =============================================================

void Storage::saveBoost()
{
    prefs.putInt(
        "pt_boostT",
        boostTemp
    );

    prefs.putInt(
        "pt_boostS",
        boostTimeSec
    );
}


// =============================================================
// PATRI - SLEEP
// =============================================================

void Storage::saveSleep()
{
    prefs.putInt(
        "pt_sleepT",
        sleepTemp
    );

    prefs.putInt(
        "pt_sleepS",
        sleepTimeSec
    );
}


// =============================================================
// PATRI - CALIBRATION
// =============================================================

void Storage::saveCal()
{
    if (!activeTip)
        return;

    String base = String("pt_") + activeTip->name;

    activeTip->tempOffset = tempOffset;
    activeTip->adcOffset  = adcOffset;

    prefs.putInt(
        (base + "_tOff").c_str(),
        tempOffset
    );

    prefs.putInt(
        (base + "_aOff").c_str(),
        adcOffset
    );
}


// =============================================================
// PATRI - TIP
// =============================================================

void Storage::saveTip()
{
    prefs.putInt(
        "pt_tipMode",
        currentTipMode
    );
}


// =============================================================
// PATRI - BUZZER
// =============================================================

void Storage::saveBuzzer()
{
    prefs.putBool(
        "pt_buzzer",
        buzzerEnabled
    );
}


// =============================================================
// FACTORY RESET
// =============================================================

void Storage::factoryReset()
{
    prefs.clear();
}