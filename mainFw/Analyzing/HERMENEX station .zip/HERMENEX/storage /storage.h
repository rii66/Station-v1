#ifndef STORAGE_H
#define STORAGE_H

#include <Arduino.h>

class Storage {
public:
    void begin();

    // =========================================================
    // SIROCCRO
    // =========================================================

    void loadSiroccroCalibration(uint16_t &c0, uint16_t &c1, uint16_t &c2);
void saveSiroccroCalibration(uint16_t c0, uint16_t c1, uint16_t c2);

    void loadSiroccroSettings(int &temp, int &fan);
    void saveSiroccroSettings(int temp, int fan);

    void loadSiroccroPID(float &kp, float &ki, float &kd);
    void saveSiroccroPID(float kp, float ki, float kd);


    // =========================================================
    // PATRI
    // =========================================================

    void loadSettings();
    void saveSettings();

    void loadPID();
    void savePID();

    void saveActivePID();

    void saveBoost();
    void saveSleep();
    void saveCal();
    void saveTip();
    void saveBuzzer();

    void factoryReset();
};

extern Storage storage;

#endif